﻿var sitemap = 
{
"rootNodes":[
{
"pageName":"wap",
"type":"Wireframe",
"url":"wap.html",
"children":[
{
"pageName":"login",
"type":"Wireframe",
"url":"login.html"},
{
"pageName":"register",
"type":"Wireframe",
"url":"register.html"},
{
"pageName":"event list",
"type":"Wireframe",
"url":"event_list.html"},
{
"pageName":"product list",
"type":"Wireframe",
"url":"product_list.html"},
{
"pageName":"product page",
"type":"Wireframe",
"url":"product_page.html",
"children":[
{
"pageName":"select pruduct",
"type":"Wireframe",
"url":"select_pruduct.html"}]},
{
"pageName":"cart page",
"type":"Wireframe",
"url":"cart_page.html"},
{
"pageName":"check out page",
"type":"Wireframe",
"url":"check_out_page.html",
"children":[
{
"pageName":"all address",
"type":"Wireframe",
"url":"all_address.html",
"children":[
{
"pageName":"select address",
"type":"Wireframe",
"url":"select_address.html",
"children":[
{
"pageName":"address province",
"type":"Wireframe",
"url":"address_province.html"},
{
"pageName":"address city",
"type":"Wireframe",
"url":"address_city.html"}]}]},
{
"pageName":"select payment",
"type":"Wireframe",
"url":"select_payment.html"},
{
"pageName":"check out finish",
"type":"Wireframe",
"url":"check_out_finish.html"}]},
{
"pageName":"my accont pic",
"type":"Wireframe",
"url":"my_accont_pic.html",
"children":[
{
"pageName":"my accont txt",
"type":"Wireframe",
"url":"my_accont_txt.html"},
{
"pageName":"order details",
"type":"Wireframe",
"url":"order_details.html"},
{
"pageName":"in site message",
"type":"Wireframe",
"url":"in_site_message.html",
"children":[
{
"pageName":"message",
"type":"Wireframe",
"url":"message.html"}]}]}]}]};
