﻿
var PageName = 'address 1';
var PageId = '678fef045de5423c8ba57774458ea564'
var PageUrl = 'address_1.html'
document.title = 'address 1';
var PageNotes = {};

if (window.OnLoad) OnLoad();
