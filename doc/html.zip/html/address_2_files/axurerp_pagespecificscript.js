﻿
var PageName = 'address 2';
var PageId = '6b7c6f4f43564dc08c2e4db75dc135fd'
var PageUrl = 'address_2.html'
document.title = 'address 2';
var PageNotes = {};

if (window.OnLoad) OnLoad();
